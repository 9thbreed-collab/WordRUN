import Phaser from "phaser"


export default class GameScene extends Phaser.Scene {

    create() {
        // Create game objects here
     

    }
}