export const MapGraphLocal = {
  next:{ 'land_1_level_1':'land_1_level_2', 'land_1_level_2':'land_1_level_3' },
  nodes:{ 'land_1_level_1':{x:20,y:70}, 'land_1_level_2':{x:50,y:45}, 'land_1_level_3':{x:80,y:30} },
  edges:{ 'land_1_level_1->land_1_level_2':1200, 'land_1_level_2->land_1_level_3':1500 }
};