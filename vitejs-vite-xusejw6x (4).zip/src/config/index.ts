// TitleScreen imports { GAME_CONFIG } from "../config"
export const GAME_CONFIG = {
  title: 'Word Game',
  width: 360,
  height: 640,
  bg: '#0d0f14'
};
